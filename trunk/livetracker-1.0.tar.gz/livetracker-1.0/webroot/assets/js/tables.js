// alternating row colors
var selectedSessionId;
function alternateRows(tableName){
	var tableObject = document.getElementById(tableName);
	alternateRowsInternal(tableObject);
}
function alternateRowsInternal(tableObject){
	var allTRs = tableObject.getElementsByTagName("tr");
	for (i=0; i < allTRs.length ; i++) {
		if(allTRs[i].id == selectedSessionId)
			allTRs[i].className = "selected";
		else if (i % 2 == 0)
			allTRs[i].className = "oddrow";
		else
			allTRs[i].className = "";
	}
}
function selectRow(ipCell){
	var listTable = ipCell.parentNode.parentNode;
	selectedSessionId = ipCell.parentNode.id;
	curSessionId = selectedSessionId;
	alternateRowsInternal(listTable);
	//clear existing update instructions and issue new one
	clearInterval(navTimerId);
	clearInterval(infoTimerId);
	//getSessionInfo();
	getNavInfo();
}