var listRequest;
var curSessionId;
var infoTimerId;
var navTimerId;
var curView;
function updateClientList(){
	try {
		listRequest = new XMLHttpRequest();
	}
	catch (error) {
		try {
			listRequest = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch (error) {
		//cant do anything for now - ignore
		alert(error);
		}
	}
	try {
		listRequest.onreadystatechange = displayClientList;
		listRequest.open("GET", "ltc?axn=ClientList&nolayout=true&siteurl=" + window.trackingSite, true);
		listRequest.send(null);
	}
	catch (error) {
		//cant do anything forn ow - ignoring
		alert(error);
	}
}
function displayClientList(){
	if (listRequest.readyState == 4) {
		// only if "OK"
		if (listRequest.status == 200) {
			var clistDiv = document.getElementById("clist");
			clistDiv.innerHTML = listRequest.responseText;
			//now also set table format
			alternateRows("clisttable");
		} else {
			alert("There was a problem retrieving the XML data:\n" + listRequest.statusText);
			//cant do anything for now - ignoring
		}
	}
}
setInterval("updateClientList()",15000);
var infoRequest
function updateSessionInfo(){
	try {
		infoRequest = new XMLHttpRequest();
	}
	catch (error) {
		try {
			infoRequest = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch (error) {
		//cant do anything for now - ignore
		alert(error);
		}
	}
	try {
		infoRequest.onreadystatechange = displaySessionInfo;
		infoRequest.open("GET", "ltc?axn=SessionInfo&sessionKey=" + curSessionId + "&nolayout=true&siteurl=" + window.trackingSite, true);
		infoRequest.send(null);
	}
	catch (error) {
		//cant do anything forn ow - ignoring
		alert(error);
	}
}
function getSessionInfo(){
	//var firstTime - not to be asynchronous
	if(curSessionId){
		updateSessionInfo();
		clearInterval(navTimerId);
		clearInterval(infoTimerId);
		infoTimerId = setInterval("updateSessionInfo()",15000);
		toggleTab("info");
	}
	return false;
}
function displaySessionInfo(){
	if (infoRequest.readyState == 4) {
		// only if "OK"
		if (infoRequest.status == 200) {
			var cdetailDiv = document.getElementById("cdetail");
			cdetailDiv.innerHTML = infoRequest.responseText;
			//set table format
			alternateRows("cdetailtable");
		} else {
			alert("There was a problem retrieving the XML data:\n" + infoRequest.statusText);
			//cant do anything for now - ignoring
		}
	}
}
var navRequest
function updateNavInfo(){
	try {
		navRequest = new XMLHttpRequest();
	}
	catch (error) {
		try {
			navRequest = new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch (error) {
		//cant do anything for now - ignore
		alert(error);
		}
	}
	try {
		navRequest.onreadystatechange = displayNavInfo;
		navRequest.open("GET", "ltc?axn=NavigationList&sessionKey=" + curSessionId + "&nolayout=true&siteurl=" + window.trackingSite, true);
		navRequest.send(null);
	}
	catch (error) {
		//cant do anything forn now - ignoring
		alert(error);
	}
}
function getNavInfo(){
	//var firstTime - not to be asynchronous
	//curSessionId = sessionId;
	if(curSessionId){
		updateNavInfo();
		clearInterval(infoTimerId);
		clearInterval(navTimerId);
		navTimerId = setInterval("updateNavInfo()",15000);
		toggleTab("nav");
	}
	return false;
}
function displayNavInfo(){
	if (navRequest.readyState == 4) {
		// only if "OK"
		if (navRequest.status == 200) {
			var cdetailDiv = document.getElementById("cdetail");
			cdetailDiv.innerHTML = navRequest.responseText;
		} else {
			alert("There was a problem retrieving the XML data:\n" + navRequest.statusText);
			//cant do anything for now - ignoring
		}
	}
}
function toggleTab(tabName){
	var infoTab = document.getElementById("info");
	var navTab = document.getElementById("nav");
	infoTab.className = "";
	navTab.className = "";
	document.getElementById(tabName).className="selected";
}