package com.ecomzera.livetracker.mvc.model;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public abstract class BaseVO implements Serializable {
	protected HashMap<String, String> customProperties; //for now allowing only string props

	public void setProperty(String name, String value){
		if(customProperties == null){
			customProperties = new HashMap<String, String>();			
		}
		customProperties.put(name, value);
	}
	public String getProperty(String name){
		if(customProperties == null){
			return null;
		}
		return customProperties.get(name);
	}
	public Set<String> getPropertyNames(){
		if(customProperties != null){
			return customProperties.keySet();
		}
		else{
			return Collections.emptySet();
		}
	}
	public Map<String, String> getAllProperties(){
		return customProperties;//not clone()//?
	}
	public void addAllProperties(Map<String, String> properties){
		if(customProperties == null){
			if(properties != null && !properties.isEmpty()){
				customProperties = new HashMap<String, String>(properties);
			}
		}
		else{
			customProperties.putAll(properties);
		}
	}
}
