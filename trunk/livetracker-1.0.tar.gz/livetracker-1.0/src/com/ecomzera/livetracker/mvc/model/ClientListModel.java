package com.ecomzera.livetracker.mvc.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import com.ecomzera.livetracker.mvc.core.LTRequest;
import com.ecomzera.livetracker.server.ClientSessionDTO;
import com.ecomzera.livetracker.server.PageVisitDTO;
import com.ecomzera.livetracker.server.Utils;

public class ClientListModel extends BaseModel {
//	private static DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM); //note it is not final 

	@Override
	public Serializable execute(LTRequest request, HttpServletResponse response) throws ServletException {
		ArrayList<SessionInfoVO> sessionList = new ArrayList<SessionInfoVO>();
		for (ClientSessionDTO clientSessionDTO : ltServer.getClientSessions().values()) {
			SessionInfoVO info = new SessionInfoVO();
			//if the latest page is closed, get the previous page
			PageVisitDTO latestPage = Utils.getLatestActivePage(clientSessionDTO);
			info.browser = clientSessionDTO.getBrowserShortName();
			info.currentPage = latestPage.getUrl();
			info.ipAddress = clientSessionDTO.getIpAddress();
			info.noOfPages = String.valueOf(clientSessionDTO.getNoOfPages());
			info.pageTime = Utils.getTimeDifference(request.currentTimeMillis(), latestPage.getRequestTime().getTime());
			if(clientSessionDTO.getFirstPage().getVisitedFromURL() != null){
				info.referer = Utils.getHostFromURL(clientSessionDTO.getFirstPage().getVisitedFromURL());
				info.refererUrl = clientSessionDTO.getFirstPage().getVisitedFromURL();
			}
			else{
				info.referer = "-";
			}
			info.referer = Utils.getHostFromURL(clientSessionDTO.getFirstPage().getVisitedFromURL());
			info.sessionId = clientSessionDTO.getSessionId();
			info.totalTime = Utils.getTimeDifference(request.currentTimeMillis(), clientSessionDTO.getFirstPage().getRequestTime().getTime());
			//now start adding custom properties...if any
			info.addAllProperties(clientSessionDTO.getAllProperties());
			info.setStartTime(clientSessionDTO.getStartTime());
			sessionList.add(info);
		}
		//now sort
		Collections.sort(sessionList);
		return sessionList;
	}
	//TODO Sorting mechanism
}