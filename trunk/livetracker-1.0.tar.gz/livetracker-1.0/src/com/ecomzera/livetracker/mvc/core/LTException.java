package com.ecomzera.livetracker.mvc.core;

public class LTException extends Exception {
	private String errorView;
	public LTException(String message) {
		super(message);
	}

	public LTException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public LTException(String message, Throwable cause, String errorView){
		this(message, cause);
		this.errorView = errorView;
	}

	public LTException(Throwable cause) {
		super(cause);
	}

	public String getErrorView() {
		return errorView;
	}

	public void setErrorView(String errorView) {
		this.errorView = errorView;
	}
}
