package com.ecomzera.livetracker.mvc.core;

import java.io.Serializable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import com.ecomzera.livetracker.server.LTServer;


public interface LTAction extends Serializable {
	void setServer(LTServer server);
	LTServer getServer();
	Serializable execute(LTRequest request, HttpServletResponse response) throws ServletException, LTException;
}
