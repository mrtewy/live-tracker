package com.ecomzera.livetracker.mvc.model;

public class NavInfoVO extends BaseVO {
	protected String page;
	protected String referer;
	protected String title;
	protected String pageTime;
	protected String refererUrl;
	protected String pageUrl;
	public String getPage() {
		return page;
	}
	public void setPage(String page) {
		this.page = page;
	}
	public String getReferer() {
		return referer;
	}
	public void setReferer(String referer) {
		this.referer = referer;
	}
	public String getpageTime() {
		return pageTime;
	}
	public void setpageTime(String pageTime) {
		this.pageTime = pageTime;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getRefererUrl() {
		return refererUrl;
	}
	public void setRefererUrl(String refererUrl) {
		this.refererUrl = refererUrl;
	}
	public String getPageUrl() {
		return pageUrl;
	}
	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}
}
