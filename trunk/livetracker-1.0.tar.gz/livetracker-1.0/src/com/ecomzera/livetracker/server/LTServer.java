package com.ecomzera.livetracker.server;

import java.util.Map;

import com.ecomzera.livetracker.capture.DocInfoGrabber;

public interface LTServer {
	void visitPage(PageInfoDTO pageInfo);
	void unloadPage(PageInfoDTO pageInfo);
	Map<String, ClientSessionDTO> getClientSessions();
	void removeSession(String sessionId);
	ClientSessionDTO getSession(String sessionId);
	DocInfoGrabber getDocInfoGrabber(PageVisitDTO pageVisit);
	void setDocInfoGrabberClass(Class<? extends DocInfoGrabber> docInfoGrabberClass);
	Class<? extends DocInfoGrabber> getDocInfoGrabberClass();
}
