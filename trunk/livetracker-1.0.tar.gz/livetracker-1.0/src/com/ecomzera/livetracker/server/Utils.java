package com.ecomzera.livetracker.server;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;


public class Utils {
	public enum BrowserType {MSIE, Firefox, Mozilla};
	private static final int MAX_STRING_DISPLAY_SIZE = 75;
	private static final int MAX_STRING_BREAK_SIZE = MAX_STRING_DISPLAY_SIZE / 2 - 2;
	public static final String SHORT_TITLE = "shortTitle";
	private static final Logger _logger = Logger.getLogger(Utils.class.getName());
	
	public static String getTimeDifference(long newTimeInMillis, long oldTimeInMillis) {
		long timeDiffInSec = (newTimeInMillis - oldTimeInMillis) / 1000;
		return getDurationAsString(timeDiffInSec);
	}
	public static String getDurationAsString(long duration){
		//maybe we can use time format instead of custom logic 
		long noOfHours = duration / (60 * 60);
		long noOfMinutes = (duration - noOfHours * 60 * 60) / 60;
		long noOfSeconds = duration - (duration / 60) * 60;
		StringBuffer sb = new StringBuffer();
		formatUnit(sb, noOfHours, "h");
		formatUnit(sb, noOfMinutes, "m");
		formatUnit(sb, noOfSeconds, "s");
		return sb.toString();		
	}

	private static void formatUnit(StringBuffer sb, long noOfUnits, String unitName) {
		if (noOfUnits == 0) {
			return;
		}
		sb.append(" ");
		sb.append(noOfUnits);
		sb.append(unitName);
		/*
		 * if(noOfUnits > 1){ sb.append("s "); }
		 */
	}

	public static String getRelativeURL(String absoluteURL, String withRespectToUrl) {
		try {
			URL url = new URL(absoluteURL);
			URL wrtUrl = new URL(withRespectToUrl);
			InetAddress urlHost = InetAddress.getByName(url.getHost());
			InetAddress withRespectToHostAddress = InetAddress.getByName(wrtUrl.getHost());
			if(urlHost.equals(withRespectToHostAddress)){
				return shortenURL(url);
			}
			else {
				return absoluteURL;
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			if (absoluteURL != null && !"".equals(absoluteURL)) {
				e.printStackTrace();
			}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return absoluteURL; // we cant do much here
	}
	public static String getRelativeURL(String absoluteURL) {
		try {
			URL url = new URL(absoluteURL);
			return shortenURL(url);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			if (absoluteURL != null && !"".equals(absoluteURL)) {
				e.printStackTrace();
			}
		}
		return absoluteURL; // we cant do much here
	}
	private static String shortenURL(URL url){
		return url.getPath() + (url.getQuery() == null ? "": "?" + url.getQuery());		
	}
	public static PageInfoDTO readPageInfoFromRequest(HttpServletRequest request){
		_logger.entering("Utils", "readPageInfoFromRequest");
		String url = request.getParameter("url");
		_logger.severe("URL Sent is..." + url);
		PageInfoDTO pageInfo = new PageInfoDTO(System.currentTimeMillis());
		pageInfo.setUri(url);
		pageInfo.setReferer(request.getParameter("ref"));
		pageInfo.setSessionId(request.getParameter("sessionId"));
		pageInfo.setBrowser(request.getParameter("browser"));
		pageInfo.setHost(request.getParameter("host"));
		pageInfo.setIpAddress(request.getParameter("ip"));
		pageInfo.setWindowName(request.getParameter("wname"));
		pageInfo.setEvent(request.getParameter("event"));
		pageInfo.setWindowTitle(request.getParameter("title"));
		_logger.exiting("Utils", "readPageInfoFromRequest");
		return pageInfo;
	}
	public static String inferBrowser(String userAgent){
		//later on add version info also
		//also instead of hardcoding the info here
		//use a properties file - TODO
		int index = -1;
		if((index = userAgent.indexOf("MSIE")) > 0){
			return inferVersionInfo(userAgent, index, BrowserType.MSIE);
		}
		else if(userAgent.contains("Firefox")){
			return inferVersionInfo(userAgent, index, BrowserType.Firefox);
		}
		else if(userAgent.contains("Mozilla")){
			return inferVersionInfo(userAgent, index, BrowserType.Mozilla);
		}
		else{
			return userAgent;
		}
	}
	private static String inferVersionInfo(String userAgent, int index, BrowserType browserType){
		if(browserType == BrowserType.MSIE){
			int semicolonAt = userAgent.indexOf(';', index);
			return userAgent.substring(index,semicolonAt);			
		}
		else if(browserType == BrowserType.Mozilla || browserType == BrowserType.Firefox){
			int indexOfRV = userAgent.indexOf("rv:");
			int indexOfBracket = userAgent.indexOf(')', indexOfRV);
			return browserType + " " + userAgent.substring(indexOfRV + 3, indexOfBracket);
		}
		return userAgent;
	}
	public static String getDisplayableString(String fullString){
		if(fullString.length() <= MAX_STRING_DISPLAY_SIZE){
			return fullString;
		}
		int l1 = fullString.length() - MAX_STRING_BREAK_SIZE;
		return fullString.substring(0, MAX_STRING_BREAK_SIZE) + "...." + fullString.substring(l1);
	}
	public static String getHostFromURL(String urlString){
		try {
			URL url = new URL(urlString);
			return url.getHost();
		} catch (MalformedURLException e) {
			return urlString;
		}
		
	}
	public static PageVisitDTO getLatestActivePage(ClientSessionDTO clientSessionDTO){
		ArrayList<PageVisitDTO> visitedPages = clientSessionDTO.getPageVisits();
		PageVisitDTO latestPage = null;
		for(int i = visitedPages.size() - 1; i >= 0; i--){
			latestPage = visitedPages.get(i);
			if(latestPage.isActive()){
				//user has this page still open - report it
				break;
			}
		}
		return latestPage;
	}

	public static void main(String[] args) {
		// Test 1
		/*
		 * long i1 = 0; long i2 =97002050L;
		 * System.out.println(getTimeDifference(i2, i1));
		 */
		// Test 2
		String url1 = "http://localhost:8080/tfe-working/content/giftflowers/flowers-and-fragrances";
		String url2 = "http://www.yahoo.com/";
		System.out.println(getRelativeURL(url1, url1));
		System.out.println(getRelativeURL(url2, url1));
	}
	public static String getShortTitle(PageVisitDTO pageVisit, LTServer ltServer) {
		if(pageVisit.getProperty(SHORT_TITLE) == null){
			//cache it now
			String shortTitle = ltServer.getDocInfoGrabber(pageVisit).getDocTitle();
			pageVisit.setProperty(SHORT_TITLE, shortTitle);
		}
		return pageVisit.getProperty(SHORT_TITLE);
	}
}
