package com.ecomzera.livetracker.server;

import java.util.ArrayList;
import java.util.logging.Logger;

public class SiteMonitorDaemon extends Thread {
	private static final long SESSION_TIMEOUT = 2 * 60 * 60 * 1000; // 2 hrs.

	private static final long PAGE_UNLOAD_TIMEOUT = 15 * 1000; // 15 seconds

	private static final long SITE_SCAN_FREQUENCY = 5 * 1000;

	private LTServer server;

	private Logger _logger;
	
	private ArrayList<String> sessionsToRemove;	//this is defined at class level rather than method leve
												//for performance reasons
	private ArrayList<String> windowsToRemove;	//this is defined at class level rather than method leve
												//for performance reasons
	
	public SiteMonitorDaemon(LTServer server){
		this.server = server;
		_logger = Logger.getLogger(SiteMonitorDaemon.class.getName());
		sessionsToRemove = new ArrayList<String>();
		windowsToRemove = new ArrayList<String>();
	}

	@Override
	public void run() {
		while (true) {
			long timeNow = System.currentTimeMillis();
			_logger.finest("No. Of Open Sessions = " + server.getClientSessions().size());
			sessionsToRemove.clear();
			// cleanup sessions if required
			for (ClientSessionDTO clientSessionDTO : server.getClientSessions().values()) {
				long inactivityTime = timeNow - clientSessionDTO.getCurrentPage().getRequestTimeLong(); 
				_logger.finest("Session Inactivity Time : " + inactivityTime);
				if (inactivityTime >= SESSION_TIMEOUT || clientSessionDTO.getActivePages().size() <= 0) {
					// this session died - bury it
					sessionsToRemove.add(clientSessionDTO.getSessionId());
				}
			}
			// now clean up the pages
			for (ClientSessionDTO clientSessionDTO : server.getClientSessions().values()) {
				windowsToRemove.clear();
				for(PageVisitDTO pageVisitDTO : clientSessionDTO.getActivePages()){
					if(!pageVisitDTO.isActive()){
						long elapsedTime = timeNow - pageVisitDTO.getLastActivityTime();
						if(elapsedTime > PAGE_UNLOAD_TIMEOUT){
							//window is closed
							windowsToRemove.add(pageVisitDTO.getWindowName());
						}
					}
				}
				for(String windowName : windowsToRemove){
					_logger.fine("Closing window " + windowName);
					clientSessionDTO.closeWindow(windowName);
				}
				if(clientSessionDTO.getActivePages().size() == 0){
					//all windows in this session closed
					sessionsToRemove.add(clientSessionDTO.getSessionId());
					//server.removeSession(clientSessionDTO.getSessionId());
				}
			}
			for(String sessionId : sessionsToRemove){
				_logger.info("Cleaning up the session ->" + sessionId);
				server.removeSession(sessionId);
			}
			
			try {
				Thread.sleep(SITE_SCAN_FREQUENCY);
			} catch (InterruptedException e) {}
		}
	}
}
