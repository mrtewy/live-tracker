package com.ecomzera.livetracker.server;

import java.util.Date;

public class PageVisitDTO extends BaseDTO implements Comparable<PageVisitDTO>{
	private String url;
	private String title;
	private String visitedFromURL;
	private Date requestTime;
	private String windowName;
	private boolean active;
	private boolean windowClosed;
	private long timeOnThisPage;

	public synchronized boolean isActive() {
		return active;
	}
	public void setActive(boolean isActive, long timeWhenSet) {
		this.active = isActive;
		timeOnThisPage = timeWhenSet - requestTime.getTime();
		/*("Time on " + url + "=" + timeOnThisPage);*/
	}
	public PageVisitDTO(String windowName, String url, String title, long requestTime, String visitedFromURL){
		this(windowName, url, title, requestTime, visitedFromURL, 0);
	}
	public PageVisitDTO(String windowName, String url, String title, long requestTime,String visitedFromURL, long timeOnThisPage){
		this.windowName = windowName;
		this.url=url;
		this.title=title;
		this.requestTime=new Date(requestTime);
		this.visitedFromURL = visitedFromURL;
		this.timeOnThisPage = timeOnThisPage;
		setActive(true, requestTime);
	}
	public Date getRequestTime() {
		return requestTime;
	}
	public String getTitle() {
		return title;
	}

	public String getUrl() {
		return url;
	}
	public String getVisitedFromURL() {
		return visitedFromURL;
	}
	public void setRequestTime(long requestTime) {
		this.requestTime = new Date(requestTime);
	}
	public int compareTo(PageVisitDTO o) {
		return (int)(o.requestTime.getTime() - requestTime.getTime());
	}
	public String getWindowName() {
		return windowName;
	}
	@Override
	public String toString() {
		return "url '" + url + "' in window '" + windowName + " @ " + requestTime + "(" + timeOnThisPage + ")";
	}
	public long getTimeOnThisPage() {
		return timeOnThisPage;
	}
	public boolean isWindowClosed() {
		return windowClosed;
	}
	public void setWindowClosed(boolean windowClosed) {
		this.windowClosed = windowClosed;
	}
	public long getRequestTimeLong(){
		return requestTime.getTime();
	}
	public long getLastActivityTime(){
		return requestTime.getTime() + timeOnThisPage;
	}
}
