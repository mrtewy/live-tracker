package com.ecomzera.livetracker.capture.impl;

import com.ecomzera.livetracker.capture.DocInfoGrabber;
import com.ecomzera.livetracker.server.PageVisitDTO;

public class DefaultDocInfoGrabberImpl implements DocInfoGrabber {
	protected PageVisitDTO pageVisit;
	public DefaultDocInfoGrabberImpl(){
		//this is required for refection methods to work OK
	}
	public DefaultDocInfoGrabberImpl(PageVisitDTO pageVisit){
		this.pageVisit = pageVisit;
	}

	public String getDocTitle() {
		return pageVisit.getTitle();
	}

	public String getAttribute(String attributeName) {
		return null; //no implementation yet
	}
	public PageVisitDTO getPageVisit() {
		return pageVisit;
	}
	public void setPageVisit(PageVisitDTO pageVisit) {
		this.pageVisit = pageVisit;
	}
}
