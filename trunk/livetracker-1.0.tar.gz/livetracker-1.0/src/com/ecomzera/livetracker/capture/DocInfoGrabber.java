package com.ecomzera.livetracker.capture;

import com.ecomzera.livetracker.server.PageVisitDTO;

public interface DocInfoGrabber {
	String getDocTitle();
	String getAttribute(String attributeName);
	void setPageVisit(PageVisitDTO pageVisit);
	PageVisitDTO getPageVisit();
}
