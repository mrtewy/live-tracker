package com.ecomzera.livetracker.capture;

import java.rmi.Remote;
import java.rmi.RemoteException;

import com.ecomzera.livetracker.server.PageInfoDTO;

public interface Recorder extends Remote {
	
	void visitPage(PageInfoDTO pageInfo) throws RemoteException;
	void unloadPage(PageInfoDTO pageInfo) throws RemoteException;
}
