package com.ecomzera.livetracker.capture.impl;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import com.ecomzera.livetracker.server.PageInfoDTO;
import com.ecomzera.livetracker.server.Utils;

public class RecordProxy {
	private static final DefaultRecorderImpl DEFAULT_RECORDER = new DefaultRecorderImpl();
	private Logger _logger = Logger.getLogger(RecordProxy.class.getName());
	public void recordMessage(HttpServletRequest request) {
		try {
			// System.out.println("fired event:"
			// +request.getParameter("event"));
			_logger.entering("RecordProxy","recordMessage");
			PageInfoDTO pageInfo = Utils.readPageInfoFromRequest(request);
			//defaultRecorderImpl.visitPage(pageInfo);
			if(pageInfo.getEvent().equals("0")){
				DEFAULT_RECORDER.visitPage(pageInfo);
			}
			else if(pageInfo.getEvent().equals("1")){
				DEFAULT_RECORDER.unloadPage(pageInfo);
			}
			else{
				//this condition should never be occuring
				_logger.exiting("RecordProxy","recordMessage");
				throw new Exception("Unknown Page Event / Invalid client request");
			}
			_logger.exiting("RecordProxy","recordMessage");
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
