var debug = true;
var openRequest, closeRequest;
var pageEventListener = "/ltrecordproxy.jsp";
function sendPageEvent(pageEvent) {
	if(openRequest == null){
		try {
			openRequest = new XMLHttpRequest();
			closeRequest = new XMLHttpRequest();
		}
		catch (error) {
			try {
				openRequest = new ActiveXObject("Microsoft.XMLHTTP");
				closeRequest = new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch (error) {
				//This is an error situation
				//however end client should not see the messages
				//but we need messages for debugging - hence debug
				if(debug)
					displayDebugError("Error creating AJAX request:\n", error);
					return;
			}
		}
	}
	var requestObject = (pageEvent == 0) ? openRequest : closeRequest;
	try {
		if(window.name == "") {
			window.name = new Date().getTime();
		}
		var docRef = (document.referrer) ? document.referrer : "";
		var pageEventSink = pageEventListener + "?event=" + pageEvent + "&url=" + escape(window.location.href) + "&ref=" + escape(docRef) + "&wn=" +window.name + "&title=" + escape(document.title);
		requestObject.open("GET", pageEventSink, true);
		requestObject.send(null);
	}
	catch (error) {
		if(debug)
			displayDebugError("Error communicating with PageEventListener:\n", error);
	}
}
sendPageEvent(0);
function displayDebugError(prefix, error){
	var r = prefix;
	for (var p in error)
		r += p + ": " + error[p] + "\n";
	alert(r);
}