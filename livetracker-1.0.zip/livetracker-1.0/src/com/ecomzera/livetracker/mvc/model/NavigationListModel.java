package com.ecomzera.livetracker.mvc.model;

import java.io.Serializable;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import com.ecomzera.livetracker.mvc.core.LTRequest;
import com.ecomzera.livetracker.server.ClientSessionDTO;
import com.ecomzera.livetracker.server.PageVisitDTO;
import com.ecomzera.livetracker.server.Utils;

public class NavigationListModel extends BaseModel {

	@Override
	public Serializable execute(LTRequest request, HttpServletResponse response) throws ServletException {
		ArrayList<NavInfoVO> pageList = new ArrayList<NavInfoVO>();
		String sessionId = request.getParameter("sessionKey");
		ClientSessionDTO clientSessionDTO = ltServer.getSession(sessionId);
		if(clientSessionDTO != null ){
			for (PageVisitDTO pageVisitDTO : clientSessionDTO.getPageVisits()) {
				NavInfoVO info = new NavInfoVO();
				info.page = Utils.getRelativeURL(pageVisitDTO.getUrl());
				info.pageUrl = pageVisitDTO.getUrl();
				info.title = Utils.getShortTitle(pageVisitDTO, ltServer);

				long displayTime = pageVisitDTO.isActive() ? (request.currentTimeMillis() - pageVisitDTO.getRequestTimeLong()) : pageVisitDTO.getTimeOnThisPage();
				info.pageTime = Utils.getDurationAsString(displayTime / 1000);
				info.referer = Utils.getRelativeURL(pageVisitDTO.getVisitedFromURL(), pageVisitDTO.getUrl());
				info.refererUrl = pageVisitDTO.getVisitedFromURL();
				pageList.add(0, info);
			}
		}
		return pageList;
	}
	//TODO Sorting mechanism
}