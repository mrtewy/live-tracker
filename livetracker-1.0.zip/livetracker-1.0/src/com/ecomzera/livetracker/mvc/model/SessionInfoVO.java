package com.ecomzera.livetracker.mvc.model;

public class SessionInfoVO extends BaseVO implements Comparable<SessionInfoVO> {
	protected String ipAddress;
	protected String host;
	protected String currentPage;
	protected String title;
	protected String referer;
	protected String pageTime;
	protected String totalTime;
	protected String noOfPages;
	protected String browser;
	protected String noOfWindows;
	protected String lastRequestTime;
	protected String sessionId;
	protected String refererUrl;
	private long startTime;
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getBrowser() {
		return browser;
	}
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	public String getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getNoOfPages() {
		return noOfPages;
	}
	public void setNoOfPages(String noOfPages) {
		this.noOfPages = noOfPages;
	}
	public String getPageTime() {
		return pageTime;
	}
	public void setPageTime(String pageTime) {
		this.pageTime = pageTime;
	}
	public String getReferer() {
		return referer;
	}
	public void setReferer(String referer) {
		this.referer = referer;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTotalTime() {
		return totalTime;
	}
	public void setTotalTime(String totalTime) {
		this.totalTime = totalTime;
	}
	public String getNoOfWindows() {
		return noOfWindows;
	}
	public void setNoOfWindows(String noOfWindows) {
		this.noOfWindows = noOfWindows;
	}
	public String getLastRequestTime() {
		return lastRequestTime;
	}
	public void setLastRequestTime(String lastRequestTime) {
		this.lastRequestTime = lastRequestTime;
	}
	public long getStartTime() {
		return startTime;
	}
	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}
	public int compareTo(SessionInfoVO o) {
		return (int)(o.startTime - startTime);
	}
	public String getRefererUrl() {
		return refererUrl;
	}
	public void setRefererUrl(String refererUrl) {
		this.refererUrl = refererUrl;
	}
	public String getCountry(){
		if(customProperties != null){
			return customProperties.get("country");
		}
		return null;
	}
}
