package com.ecomzera.livetracker.mvc.model;

import java.io.Serializable;
import java.text.DateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import com.ecomzera.livetracker.mvc.core.LTRequest;
import com.ecomzera.livetracker.server.ClientSessionDTO;
import com.ecomzera.livetracker.server.PageVisitDTO;
import com.ecomzera.livetracker.server.Utils;

public class SessionInfoModel extends BaseModel {

	private static DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM); //note it is not final 

	@Override
	public Serializable execute(LTRequest request, HttpServletResponse response) throws ServletException {
		String sessionId = request.getParameter("sessionKey");
		SessionInfoVO info = new SessionInfoVO();
		ClientSessionDTO clientSessionDTO = ltServer.getSession(sessionId);
		if(clientSessionDTO != null){
			PageVisitDTO latestPage = Utils.getLatestActivePage(clientSessionDTO);
			info.ipAddress = clientSessionDTO.getIpAddress();
			info.host = clientSessionDTO.getRemoteHost(); 
			info.currentPage = latestPage.getUrl();
			info.browser = clientSessionDTO.getBrowserShortName();
			info.lastRequestTime = dateFormat.format(latestPage.getRequestTime());
			info.noOfPages = String.valueOf(clientSessionDTO.getNoOfPages());
			info.noOfWindows = String.valueOf(clientSessionDTO.getActivePages().size());
			info.pageTime = Utils.getTimeDifference(request.currentTimeMillis(), clientSessionDTO.getCurrentPage().getRequestTime().getTime());
			info.referer = clientSessionDTO.getFirstPage().getVisitedFromURL();
			info.sessionId = clientSessionDTO.getSessionId();
			info.title = Utils.getShortTitle(latestPage, ltServer);
			info.totalTime = Utils.getTimeDifference(request.currentTimeMillis(), clientSessionDTO.getFirstPage().getRequestTime().getTime());
		}
		return info;
	}
	//TODO Sorting mechanism
}