package com.ecomzera.livetracker.mvc.model;

import java.io.Serializable;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import com.ecomzera.livetracker.mvc.core.LTAction;
import com.ecomzera.livetracker.mvc.core.LTException;
import com.ecomzera.livetracker.mvc.core.LTRequest;
import com.ecomzera.livetracker.server.LTServer;

public abstract class BaseModel implements LTAction {
	protected LTServer ltServer;
	protected Logger _logger;
	public BaseModel(){
		_logger = Logger.getLogger(this.getClass().getName());
	}
	public abstract Serializable execute(LTRequest request, HttpServletResponse response) throws ServletException, LTException ;

	public void setServer(LTServer server) {
		this.ltServer = server;
	}
	public LTServer getServer() {
		return ltServer;
	}
}
