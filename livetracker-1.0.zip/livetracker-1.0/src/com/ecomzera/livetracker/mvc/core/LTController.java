package com.ecomzera.livetracker.mvc.core;

import java.io.IOException;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecomzera.livetracker.server.LTServer;
import com.ecomzera.livetracker.server.LTServerFactory;
import com.ecomzera.livetracker.server.PageInfoDTO;
import com.ecomzera.livetracker.server.Utils;



public class LTController extends HttpServlet {
	//not using properties file
	//use convention as follows
	//"com.ecomzera.livetracker.mvc.model" + axnKey + "Model" is the name of the action class
	//axnKey + "View.jsp" is the name of the jsp view
	
	public static final String LT_OUTPUT_DIRECT = "LT_OUTPUT_DIRECT";

	private static final String ERROR_PAGE = "/errorPage.jsp";
	
	private static final String MODEL_PREFIX = "com.ecomzera.livetracker.mvc.model.";
	private static final String MODEL_SUFFIX = "Model";
	private static final String VIEW_PREFIX  = "/WEB-INF/jsp/";
	private static final String VIEW_SUFFIX = "View.jsp"; 
	private static final Hashtable<String, Class<LTAction>> MODEL_CACHE = new Hashtable<String, Class<LTAction>>();
	protected Logger _logger;

	public static final String LT_VO = "LT_VO";

	static final String LT_VIEW = "LT_VIEW";

	public static final String PARAM_LAYOUT = "layout";
	public static final String PARAM_NO_LAYOUT = "nolayout";
	public static final String LT_RECORD_PROXY_LOCATION = "siteurl";
	
	public LTController(){
		 _logger = Logger.getLogger(this.getClass().getName());
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		_ltService(request, response);
	}
	protected void _ltService(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//first check if ltrecordproxylocation is evaluated...if not.. do it now...
		//and store it in session to be used by TrackView.jsp
		cacheRecordProxyLocation(request);
		LTRequest ltr = new LTRequest(request);
		String axn = request.getParameter("axn");
		if(axn == null){
			_logger.severe("Action arugment not specified.");
			request.getRequestDispatcher(ERROR_PAGE).forward(request, response);
			return;
		}
		_logger.fine("Looking up action-" + axn);
		LTAction action = getAction(axn);
		if(action != null){
			_logger.fine("Looking up LT Server");
			LTServer ltServer = getLTServer(ltr);
			_logger.finer("Found LTServer -> " + ltServer);
			action.setServer(ltServer);
			Serializable vo = null;
			try {
				_logger.fine("Executing " + action);
				vo = action.execute(ltr, response);
				_logger.fine("Successfully finished " + action);
			} catch (LTException e) {
				e.printStackTrace();
				request.setAttribute("LT_ERROR", e);
				String errorPage = getErrorPage(e.getErrorView());
				if(errorPage == null){
					errorPage = axn;
				}
				renderView(request, response, errorPage);
				return;
			}
			request.setAttribute(LT_VO, vo);
		}
		//now put the server info into session
		
		//no action configured implies no biz logic
		//direct send the request to view
		String outputDirect = (String)request.getAttribute(LT_OUTPUT_DIRECT);
		if(outputDirect == null){
			renderView(request, response, axn);
		}
	}
	private void cacheRecordProxyLocation(HttpServletRequest request){
		//first check if ltrecordproxylocation is evaluated...if not.. do it now...
		//and store it in session to be used by TrackView.jsp
		HttpSession session = request.getSession(true); //forcing session to be created
		String ltRecordProxyLocation = (String)session.getAttribute(LT_RECORD_PROXY_LOCATION);
		if(ltRecordProxyLocation == null){
			//being called for the first time
			//so initialize and store
			//StringBuffer sb = new StringBuffer(request.getProtocol());
			StringBuffer sb = new StringBuffer("http");
			if(request.isSecure()){
				sb.append('s');
			}
			sb.append("://");
			sb.append(request.getHeader("host"));
			sb.append(request.getContextPath());
			if(sb.charAt(sb.length() - 1) != '/'){
				sb.append("/");
			}
			ltRecordProxyLocation = sb.toString();
			session.setAttribute(LT_RECORD_PROXY_LOCATION, ltRecordProxyLocation);
		}
	}
	public void renderView(HttpServletRequest request, HttpServletResponse response, String axn) throws ServletException, IOException{
		setNonCacheable(response);
		//send the request to the layout, which will insert the appropriate view
		//request.getRequestDispatcher(VIEW_PREFIX + axn + VIEW_SUFFIX).include(request, response);
		String view = getView(axn);
		request.setAttribute(LT_VIEW, view);
		String target = getLayout(request, axn);
		if(target == null){
			target = view;
		}
		_logger.fine("Sending control to render " + target);
		request.getRequestDispatcher(target).include(request, response);
	}
	
	protected String getLayout(HttpServletRequest request, String axn){
		String noLayout = request.getParameter(PARAM_NO_LAYOUT);
		if(noLayout != null){
			return null;
		}
		noLayout = (String)request.getAttribute(PARAM_NO_LAYOUT);
		if(noLayout != null){
			return null;
		}
		String layout = request.getParameter(PARAM_LAYOUT);
		if(layout != null){
			return getLayoutJSP(layout);
		}
		layout = (String)request.getAttribute(PARAM_LAYOUT);
		if(layout != null){
			return getLayoutJSP(layout);
		}
		return getLayoutJSP("default");
	}
	protected String getLayoutJSP(String layout){
		return "/WEB-INF/jsp/layouts/" + layout + "Layout.jsp";
	}

	protected String getErrorPage(String errorView) {
		return errorView;// getView(errorView);
	}

	protected String getView(String axn) {
		return VIEW_PREFIX + axn + VIEW_SUFFIX;
	}

	@SuppressWarnings("unchecked")
	protected LTAction getAction(String axn) {
		//synchronized block here
		try {
			Class<LTAction> actionClass = MODEL_CACHE.get(axn);
			if(actionClass != null){
					return actionClass.newInstance();
			}
			else{
				String axnModelName = MODEL_PREFIX + axn + MODEL_SUFFIX;
				//see if the corresponding class exists in the classpath
				try{
					actionClass = (Class<LTAction>) Thread.currentThread().getContextClassLoader().loadClass(axnModelName);
					if(actionClass != null){
						MODEL_CACHE.put(axn, actionClass);
						return actionClass.newInstance();
					}
				}
				catch(ClassCastException cce){
					//not interested - ignore - let it move ahead => no action configured
					return null;
				} catch (ClassNotFoundException e) {
					//not interested - ignore - let it move ahead => no action configured
					return null;
				}
			}
		} catch (InstantiationException e) {
			//not interested - ignore - let it move ahead => no action configured
			return null;
		} catch (IllegalAccessException e) {
			//not interested - ignore - let it move ahead => no action configured
			return null;
		}
		return null;
	}
	public static void main(String[] args) throws Exception{

		
	}
	protected LTServer getLTServer(LTRequest request){
		PageInfoDTO pageInfo = Utils.readPageInfoFromRequest(request);
		LTServer ltServer = LTServerFactory.getInstance().getLTServer(pageInfo);
		return ltServer;
	}
	protected void setNonCacheable(HttpServletResponse response){
		//perform no cache
		response.setDateHeader ("Expires", 0);
		response.setHeader("Pragma", "no-cache"); 
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Cache-Control","private");
		response.setHeader("Cache-Control","max-age=0"); 
	}
}
