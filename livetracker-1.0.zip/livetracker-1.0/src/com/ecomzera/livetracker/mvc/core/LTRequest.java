package com.ecomzera.livetracker.mvc.core;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class LTRequest extends HttpServletRequestWrapper {
	private long currentTime;
	public LTRequest(HttpServletRequest request) {
		super(request);
		currentTime =System.currentTimeMillis();
	}
	public long currentTimeMillis(){
		return currentTime;
	}
}
