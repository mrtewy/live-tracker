package com.ecomzera.livetracker.capture.impl.ez;

import java.rmi.RemoteException;

import com.ecomzera.livetracker.capture.Recorder;
import com.ecomzera.livetracker.server.PageInfoDTO;

public class RecorderImpl implements Recorder {

	public RecorderImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void visitPage(PageInfoDTO pageInfo) throws RemoteException {
		// TODO Auto-generated method stub

	}

	public void unloadPage(PageInfoDTO pageInfo) throws RemoteException {
		// TODO Auto-generated method stub

	}

}
