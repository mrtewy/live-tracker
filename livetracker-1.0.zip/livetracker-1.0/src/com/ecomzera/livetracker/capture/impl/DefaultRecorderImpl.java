package com.ecomzera.livetracker.capture.impl;

import java.rmi.RemoteException;
import java.util.logging.Logger;

import com.ecomzera.livetracker.capture.Recorder;
import com.ecomzera.livetracker.server.LTServer;
import com.ecomzera.livetracker.server.LTServerFactory;
import com.ecomzera.livetracker.server.PageInfoDTO;

public class DefaultRecorderImpl implements Recorder {

	//private static LTServer LOCAL_SERVER;

	private Logger _logger;

	public DefaultRecorderImpl() {
		super();
		_logger = Logger.getLogger(DefaultRecorderImpl.class.getName());
	}

	public void visitPage(PageInfoDTO pageInfo) throws RemoteException {
		_logger.entering("DefaultRecorderImpl", "visitPage");
		LTServerFactory factory = LTServerFactory.getInstance();
		_logger.info("LT Factory creation successful.");
		LTServer ltServer = factory.getLTServer(pageInfo);
		_logger.info("LTServer obtained successfully");
		if(ltServer == null){
			_logger.warning("Receiving request for 'unauthorized / unregistered site' ->" + pageInfo.getUri());
		}
		else{
			ltServer.visitPage(pageInfo);			
		}
		_logger.exiting("DefaultRecorderImpl", "visitPage");
	}

	public void unloadPage(PageInfoDTO pageInfo) throws RemoteException {
		_logger.entering("DefaultRecorderImpl", "unloadPage");
		LTServer ltServer = LTServerFactory.getInstance().getLTServer(pageInfo);
		if(ltServer == null){
			_logger.warning("Receiving request for 'unauthorized / unregistered site' ->" + pageInfo.getUri());
		}
		else{
			ltServer.unloadPage(pageInfo);
		}
		_logger.exiting("DefaultRecorderImpl", "unloadPage");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		DefaultRecorderImpl recorder = new DefaultRecorderImpl();
		recorder._logger.info("Starting the Unit Test of Monitors##############");		
		PageInfoDTO pageInfo = new PageInfoDTO(System.currentTimeMillis());
		pageInfo.setBrowser("IE");
		pageInfo.setEvent("0");
		pageInfo.setHost("myhost");
		pageInfo.setIpAddress("9823749237");
		pageInfo.setReferer("sfsdfsdf");
		pageInfo.setSessionId("1");
		pageInfo.setUri("sdhfsdjflk");
		pageInfo.setWindowName("window1");
		Thread.sleep(1000);
		recorder.visitPage(pageInfo);
		recorder._logger.info("Just visited the page");
		Thread.sleep(2000);
		recorder.unloadPage(pageInfo);
		recorder._logger.info("Unloading now Done.");
	}
}
