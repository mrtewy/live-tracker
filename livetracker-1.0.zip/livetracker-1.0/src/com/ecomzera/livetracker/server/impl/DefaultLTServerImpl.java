package com.ecomzera.livetracker.server.impl;

import java.util.Hashtable;
import java.util.Properties;
import java.util.logging.Logger;


import com.ecomzera.livetracker.capture.DocInfoGrabber;
import com.ecomzera.livetracker.capture.impl.DefaultDocInfoGrabberImpl;
import com.ecomzera.livetracker.server.ClientSessionDTO;
import com.ecomzera.livetracker.server.LTServer;
import com.ecomzera.livetracker.server.PageInfoDTO;
import com.ecomzera.livetracker.server.PageVisitDTO;
import com.ecomzera.livetracker.server.SiteMonitorDaemon;

public class DefaultLTServerImpl implements LTServer {
	private Hashtable<String, ClientSessionDTO> clientSessions;
	private Class<? extends DocInfoGrabber> docInfoGrabberClass = null;

	private Logger _logger;
	//ClientSessionMonitorDaemon clientSessionMonitorDaemon;
	//PageMonitorDaemon pageMonitorDaemon;
	SiteMonitorDaemon siteMonitorDaemon;

	public DefaultLTServerImpl(Properties props) {
		_logger = Logger.getLogger(DefaultLTServerImpl.class.getName());
		clientSessions = new Hashtable<String, ClientSessionDTO>();
		//clientSessionMonitorDaemon = new ClientSessionMonitorDaemon(this);
		//pageMonitorDaemon = new PageMonitorDaemon(this);
		siteMonitorDaemon = new SiteMonitorDaemon(this);
		init();
	}

	public void visitPage(PageInfoDTO pageInfo) {
		_logger.entering(DefaultLTServerImpl.class.getName(), "visitPage", pageInfo);
		ClientSessionDTO clientSessionDTO = (ClientSessionDTO) clientSessions.get(pageInfo.getSessionId());
		_logger.fine("Operating on ClientSession ->" + clientSessionDTO);
		boolean isNewSession = false;
		if (clientSessionDTO == null) {
			clientSessionDTO = new ClientSessionDTO(pageInfo.getSessionId());
			//Adding new session only after page traversal is complete - intentional
			//this is to prevent the monitors from scanning this session without the
			//first page being put in
			_logger.info("New Session Created -> " + clientSessionDTO);
			clientSessionDTO.setIpAddress(pageInfo.getIpAddress());
			clientSessionDTO.setBrowserName(pageInfo.getBrowser());
			clientSessionDTO.setRemoteHost(pageInfo.getHost());
			isNewSession = true;
		}
		PageVisitDTO pageVisit = new PageVisitDTO(pageInfo.getWindowName(), pageInfo.getUri(),
				pageInfo.getWindowTitle(),pageInfo.getRequestTime(), pageInfo.getReferer());
		clientSessionDTO.addPageVisit(pageVisit);
		if(isNewSession){
			clientSessions.put(pageInfo.getSessionId(), clientSessionDTO);			
		}
		_logger.finer("In defaultLTServerImpl after addpageVisit()");
	}

	private void init() {
		//clientSessionMonitorDaemon.start();
		//pageMonitorDaemon.start();
		siteMonitorDaemon.start();
	}

	public void unloadPage(PageInfoDTO pageInfo) {
		ClientSessionDTO clientSessionDTO = (ClientSessionDTO) clientSessions.get(pageInfo.getSessionId());
		// need not check for null here because....
		// unload cannot fire without first firing load
		// assuming a non-null value - TODO - validate this assumption
		
		//last page in clientsessions with the given window name
		//will be this page .. Do we need to check for URL explicitly
		//I do not think so
		//synchornize????
		if(clientSessionDTO != null){
			PageVisitDTO pageVisit = clientSessionDTO.getActivePageInWindow(pageInfo.getWindowName());
			pageVisit.setActive(false, pageInfo.getRequestTime());
		}
		//_logger.severe("Received \"deactivate\" signal on a non-existing page '" + pageInfo.getUri() + "' from window '" + pageInfo.getWindowName());
	}

	public Hashtable<String, ClientSessionDTO> getClientSessions() {
		return clientSessions;
	}

	public void removeSession(String sessionId) {
		clientSessions.remove(sessionId);		
	}

	public ClientSessionDTO getSession(String sessionId) {
		return clientSessions.get(sessionId);
	}

	public DocInfoGrabber getDocInfoGrabber(PageVisitDTO pageVisit) {
		DocInfoGrabber docInfoGrabber = null;
		if(docInfoGrabberClass == null){
			docInfoGrabber = new DefaultDocInfoGrabberImpl();
		}
		else{
			try {
				docInfoGrabber = docInfoGrabberClass.newInstance();
			} catch (Exception e) {
				e.printStackTrace(); //this is catch all
									 //cant do anything much so create docInfoGrabber
				docInfoGrabber = new DefaultDocInfoGrabberImpl(); 
			}
		}
		docInfoGrabber.setPageVisit(pageVisit);
		return docInfoGrabber;
	}

	//not a great way of implementation...but OK
	public void setDocInfoGrabberClass(Class<? extends DocInfoGrabber> docInfoGrabberClass) {
		this.docInfoGrabberClass = docInfoGrabberClass;
	}

	public Class<? extends DocInfoGrabber> getDocInfoGrabberClass() {
		return docInfoGrabberClass;
	}
}