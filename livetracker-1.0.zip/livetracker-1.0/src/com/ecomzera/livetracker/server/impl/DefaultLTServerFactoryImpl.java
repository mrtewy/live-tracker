package com.ecomzera.livetracker.server.impl;

import java.util.Properties;

import com.ecomzera.livetracker.server.LTServer;
import com.ecomzera.livetracker.server.LTServerFactory;
import com.ecomzera.livetracker.server.PageInfoDTO;

public class DefaultLTServerFactoryImpl extends LTServerFactory {
	private static LTServer _instance;

	public LTServer getLTServer(PageInfoDTO pageInfo) {
		// read the properties file and
		// create the instance

		Properties props = new Properties();
		if (_instance == null) {
			_instance = new DefaultLTServerImpl(props);
		}
		return _instance;
	}

	@Override
	public void init() {
		//nothing to do
	}
}
