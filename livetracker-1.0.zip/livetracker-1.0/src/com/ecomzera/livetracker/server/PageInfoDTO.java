package com.ecomzera.livetracker.server;

public class PageInfoDTO extends BaseDTO {
	private String uri;
	private String referer;
	private String sessionId;
	private String windowName;
	private String IpAddress;
	private String host;
	private String browser;
	private String event;
	private long requestTime;
	private String windowTitle;
	public PageInfoDTO(long requestTime){
		this.requestTime = requestTime;
	}
	public String getBrowser() {
		return browser;
	}
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getIpAddress() {
		return IpAddress;
	}
	public void setIpAddress(String ipAddress) {
		IpAddress = ipAddress;
	}
	public String getReferer() {
		return referer;
	}
	public void setReferer(String referer) {
		this.referer = referer;
	}
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	public String getWindowName() {
		return windowName;
	}
	public void setWindowName(String windowName) {
		this.windowName = windowName;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	//TODO - refactor
	/*private String inferBrowser(String userAgent){
		//later on add version info also
		//also instead of hardcoding the info here
		//use a properties file - TODO
		if(userAgent.contains("MSIE")){
			return "Internet Explorer";
		}
		else if(userAgent.contains("Firefox")){
			return "Firefox";
		}
		else if(userAgent.contains("Mozilla")){
			return "Mozilla";
		}
		else{
			return userAgent;
		}
	}*/
	public long getRequestTime() {
		return requestTime;
	}
	public String getWindowTitle() {
		return windowTitle;
	}
	public void setWindowTitle(String windowTitle) {
		this.windowTitle = windowTitle;
	}
	
}
