package com.ecomzera.livetracker.server;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;

public class ClientSessionDTO extends BaseDTO {
	private String ipAddress;

	private String browserName;

	private String remoteHost;

	private String sessionId;
	
	private ArrayList<PageVisitDTO> pageVisits;
	
	private Hashtable<String, PageVisitDTO> activeWindows;

	//derived fields - for performance only
	private String browserShortName;

	public ArrayList<PageVisitDTO> getPageVisits() {
		return pageVisits;
	}

	public ClientSessionDTO(String sessionId) {
		this.sessionId = sessionId;
		pageVisits = new ArrayList<PageVisitDTO>();
		activeWindows = new Hashtable<String, PageVisitDTO>();
	}

	public String getBrowserName() {
		return browserName;
	}

	public void setBrowserName(String browserName) {
		this.browserName = browserName;
		browserShortName = Utils.inferBrowser(browserName);
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
		//now also set the host name
	}
	
	public void addPageVisit(PageVisitDTO pageVisit){
		pageVisits.add(pageVisit);
		activeWindows.put(pageVisit.getWindowName(), pageVisit);
		//pageVisit.setActive(true, pageVisit.getRequestTimeLong());
	}

	public String getRemoteHost() {
		return remoteHost;
	}

	public void setRemoteHost(String remoteHost) {
		this.remoteHost = remoteHost;
	}

	public PageVisitDTO getCurrentPage() {
		return pageVisits.get(pageVisits.size() - 1);
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer("id=");
		sb.append(sessionId);
		/*sb.append("windows={");
		for(Object obj : windowsOpened.values()){
			sb.append(obj);
			sb.append(",");
		}
		sb.append("}");*/
		return sb.toString();
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public int getNoOfPages() {
		return pageVisits.size();
	}
	
	public PageVisitDTO getFirstPage(){
		return pageVisits.get(0);
	}
	public long getStartTime(){
		return getFirstPage().getRequestTime().getTime();
	}
	public PageVisitDTO getActivePageInWindow(String windowName){
		return activeWindows.get(windowName);
	}

	public void closeWindow(PageVisitDTO pageVisitDTO) {
		activeWindows.remove(pageVisitDTO.getWindowName());
	}
	public void closeWindow(String windowName) {
		activeWindows.remove(windowName);
	}
	public Collection<PageVisitDTO> getActivePages(){
		return activeWindows.values();
	}

	public String getBrowserShortName() {
		return browserShortName;
	}
}
