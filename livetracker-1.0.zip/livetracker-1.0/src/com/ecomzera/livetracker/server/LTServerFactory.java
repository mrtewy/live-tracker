package com.ecomzera.livetracker.server;

import com.ecomzera.livetracker.server.impl.DefaultLTServerFactoryImpl;

public abstract class LTServerFactory {
	private static LTServerFactory _instance;
	public static final String LT_SERVER_FACTORY_IMPL = "com.ecomzera.livetracker.server.LTServerFactoryImpl";
	public LTServerFactory() {
	}
	public static final LTServerFactory getInstance(){ //synchronized?
		//in future this will be upgraded to
		//use jndi type of factory instantiation
		if(_instance == null){
			String factoryClassName = System.getProperty(LT_SERVER_FACTORY_IMPL);
			if(factoryClassName == null){
				_instance = new DefaultLTServerFactoryImpl();
			}
			else{
				try {
					Class factoryClass = Thread.currentThread().getContextClassLoader().loadClass(factoryClassName);
					_instance = (LTServerFactory) factoryClass.newInstance();
					
		
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					_instance = new DefaultLTServerFactoryImpl();
					
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
					_instance = new DefaultLTServerFactoryImpl();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
					_instance = new DefaultLTServerFactoryImpl();
				}
			}
			_instance.init();
		}
		
		return _instance;
	}
	public abstract LTServer getLTServer(PageInfoDTO pageInfo); //throws what exception?
	public abstract void init();

}
